# Support Analyst & Operational Risk Management Portfolio

**Faith Babs** | [LinkedIn](#) | [Resume](#)

---

## About

Technical Support Analyst with 3+ years of enterprise SaaS experience specializing in **operational risk management, incident lifecycle management, and process improvement**. Proven track record in **root cause analysis, cross-functional stakeholder coordination, and risk mitigation** across billing, finance, and platform operations.

This portfolio demonstrates practical application of **GRC (Governance, Risk, and Compliance) frameworks** in real-world operational technology environments, showcasing skills directly transferable to IT Risk Analyst, Operational Risk Analyst, and GRC Analyst roles.

---

## Core Competencies

- **Incident & Problem Management (ITIL)** – Full lifecycle from detection to post-incident review
- **Risk Assessment & Mitigation** – Root cause analysis, control gap identification, preventive measures
- **Stakeholder Management** – Cross-functional coordination with Engineering, Product, Finance, Sales, Client Success
- **Process Improvement** – 15% reduction in repeat incidents, 30% faster analyst onboarding
- **Documentation & Reporting** – Risk registers, incident reports, KPI dashboards, SOPs
- **Vendor Coordination** – Tier 2/3 escalation management, offshore vendor training and quality assurance

**Technical Skills:** Salesforce, Jira, ServiceNow, Tableau, SQL, Swagger, IQL, Confluence

---

## Portfolio Contents

### 📋 [Incident Reports](./incident-reports/)
Professional operational risk incident reports demonstrating:
- Impact assessment and risk rating
- Root cause analysis
- Control failure identification
- Risk mitigation recommendations
- Stakeholder communication and escalation management

**Featured Incidents:**
1. [Finance Platform Outage – Post Invoice Adjustment Tool](./incident-reports/incident-001-finance-tool-outage.md)
2. [Agency Dashboard Data Integrity Issue](./incident-reports/incident-002-agency-dashboard-data-issue.md)
3. [Salesforce Platform Availability Incident](./incident-reports/incident-003-salesforce-page-loading.md)

### 📊 [Risk Management Artifacts](./risk-artifacts/)
- [Operational Risk Register](./risk-artifacts/operational-risk-register.md) – Structured incident tracking and risk classification
- [Control Matrix](./risk-artifacts/control-matrix.md) – Preventive, detective, and corrective controls mapping
- [KRI Dashboard](./risk-artifacts/kri-dashboard.md) – Key Risk Indicators tracking and trend analysis

### 📝 [Process Documentation](./process-documentation/)
- [Tier Escalation Framework](./process-documentation/tier-escalation-framework.md)
- [Incident Management Playbook](./process-documentation/incident-management-playbook.md)
- [Issue Type Taxonomy](./process-documentation/issue-taxonomy.md)

### 🎯 [Projects & Initiatives](./projects/)
- [SQL Reporting Workspace](./projects/sql-reporting-workspace.md) – Self-taught SQL development for operational visibility
- [AI-Driven Knowledge Management](./projects/ai-knowledge-management.md) – Process automation initiative
- [AI Communication Clarity Agent Pilot](./projects/ai-pilot-feedback.md) – Technology evaluation and UX feedback

---

## Key Achievements

✅ **Reduced repeat operational incidents by 15%** through systematic root cause analysis and preventive controls implementation

✅ **Improved analyst onboarding efficiency by 30%** through comprehensive documentation and knowledge management

✅ **Maintained 95%+ CSAT** from internal stakeholders (Sales, Client Success, Finance teams)

✅ **Self-taught SQL** and built enterprise reporting solution enabling data-driven operational decisions

✅ **Selected by leadership** to pilot AI-driven process improvement initiatives

---

## Career Objective

Transitioning from **Technical Support Operations** to **IT Risk & GRC roles**, leveraging demonstrated expertise in:
- Operational risk identification and assessment
- Incident lifecycle management (ITIL frameworks)
- Control effectiveness evaluation
- Cross-functional stakeholder engagement
- Process improvement and risk mitigation
- Technical documentation and reporting

**Target Roles:** IT Risk Analyst | GRC Analyst | Operational Risk Analyst | Vendor Risk Analyst

---

## Contact

**LinkedIn:** [Your LinkedIn URL]  
**Email:** [Your Email]  
**Resume:** [Link to Resume]

---

## Disclaimer

All examples in this portfolio are **sanitized case studies** based on real-world operational risk management work. Proprietary company information, system names, and specific business details have been redacted or anonymized to protect confidential information.

---

*Last Updated: March 2026*
